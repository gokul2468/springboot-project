package com.tnsif.ShoppingMallManagment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingMallManagmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingMallManagmentApplication.class, args);
	}

}

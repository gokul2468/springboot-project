package com.tnsif.ShoppingMallManagment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingMallManagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
